<img src="{{asset('assets\img\car-parking.png')}}" alt="Site Logo" style="height: 50px; width: 50px;">
